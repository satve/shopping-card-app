import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ItemList from './ItemList'
import CreateItem from './createItems.js'

class App extends Component {
  state = {
    screen: 'create',
  items :
   [{
    name: 'pen',
    price: 0.03,
    description: "blue pen",
    url: "https://www.colido.com/wp-content/uploads/2016/01/CoLiDo-3D-Pen.jpg",
    amount: 0,
},
{
    name: 'book',
    price: 10,
    description: "colored pages",
    url: "http://beenandgoing.com/wp-content/uploads/2015/04/LFTTVPBookImage.png",
    amount: 0,
},
{
    name: 'bag',
    price: 15,
    description: "more pockets",
    url: "https://ae01.alicdn.com/kf/HTB1FBEsJpXXXXcWXVXXq6xXFXXXf/New-2016-Fashion-Mini-Bags-PU-Leather-College-Bag-Rivet-Backpacks-Knitting-Leather-Backpack-Women-Free.jpg_640x640.jpg",
    amount: 0,
  },
{
    name: 'coke',
    price: 0.99,
    description: "diet coke",
    url: "http://www.lastratapizza.com/wp-content/uploads/2017/08/Diet-coke.jpg",
    amount: 0,
},
]
  }

  removeItem = (item) => {
    this.setState((state) => ({
           items: state.items.filter((c) => c.id !== item.id)
          }))
           }
      


  render() {
    return (
      <div className="App">
       {this.state.screen === 'list' && (
          <ItemList
            onDeleteItem={this.removeItem}
            items={this.state.items}
            onNavigate={() => {
                 this.setState({ screen: 'create' })
                   }}
          />
        )}
        {this.state.screen === 'create' && (
          <CreateItem/>
        )}
      </div>
    );
  }
}

export default App;
