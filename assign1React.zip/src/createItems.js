import React, { Component } from 'react';

class CreateItem extends Component {
  render() {
    return (
      <div>Create item!</div>
    )
  }
}

export default CreateItem;