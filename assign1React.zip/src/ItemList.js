import React from 'react'
import PropTypes from 'prop-types'

function ItemList (props) {
     return (
        <ul className='list'>
        {props.items.map((items) => (
       <li key={items.id}>
    
       <div class="container">  <div><strong><img src={items.url} alt=""/></strong>
       {items.amount < 1 && 
            <div>your cart is empty.</div>
          }
<a 
   href='#create'
            onClick={this.props.onNavigate}
            className='add-contact'
                     >Add Contact</a>

       
 </div> 
      <strong><div>{items.name}</div> </strong>
      <strong><div>{items.price}</div></strong>
      <strong><div>{items.description}</div></strong>
      <strong><div>{items.amount}</div></strong>
     
 <button onClick={() => props.onDeleteItem(items)} className='item-remove'>remove</button>
                   
                   
                     </div>
     </li> 
         ))}
         </ul>
   
    )
   }

   ItemList.propTypes = {
    items: PropTypes.array.isrequired,
    onDeleteItem: PropTypes.func.isRequired
  } 

export default ItemList;